repo-for-windows-hack
=====================

Hack for the repo script in Android so that it can somewhat be used on Windows
